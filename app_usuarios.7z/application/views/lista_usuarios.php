<html>
<head>
	<title>Título</title>
</head>
<body>
	<h1>Lista</h1>
	<hr>
    <a href="/produto/cadastraProdutoView">Cadastrar</a>
    <table border=1>
        <thead>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
        </thead>
        <tbody>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?= $usuario->id ?></td>
                    <td><?= $usuario->nome ?></td>
                    <td><?= $usuario->email ?></td>
                    <td><a href="/usuarios/editaProdutoView?id=<?= $usuario->id ?>">Editar</a></td>
                    <td><a href="/usuarios/excluir?id=<?= $usuario->id ?>">Excluir</a></td>
                </tr>
            <?php endforeach ; ?>
        </tbody>
</table>
</body>
</html>