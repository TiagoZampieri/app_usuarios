<?php

class Usuario extends CI_Controller {

	public function index() {
		$this->load->view('lista_usuarios');
	}

	public function listaUsuarios() {
		echo "renderiza lista";
	}

	public function insereDb() {
		echo "insere na tabela";
	}

	public function alteraDb() {
		echo "altera na tabela";
	}

	public function deleteDb() {
		echo "deleta na tabela";
	}
}